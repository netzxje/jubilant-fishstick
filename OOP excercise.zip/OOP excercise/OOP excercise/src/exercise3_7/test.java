package exercise3_7;

public class test {
    public static void main(String[] args) {
        Ball ball = new Ball(50, 25, 0);

        Player player1 = new Player(1,  30, 20, 0);
        Player player2 = new Player(2,  70, 30, 0);

        System.out.println("Ball: " + ball.toString());


        System.out.println("\n--- Game Starts ---\n");

        player1.move(15, 5);
        player1.kick(ball);

        player2.move(-15, -5);
        player2.kick(ball);

        System.out.println("\n--- Game Ends ---\n");
        System.out.println("Final ball : " + ball.toString());
    }
}

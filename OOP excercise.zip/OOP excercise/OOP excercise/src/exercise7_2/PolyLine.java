package exercise7_2;

import java.util.ArrayList;
import java.util.List;

public class PolyLine {
    private List<Point> points;

    public PolyLine(List<Point> points) {
        this.points = points;
    }
    public PolyLine() {
        this.points = new ArrayList<>();
    }
    public void appendPoint(int x,int y){
        Point point=new Point(x,y);
        points.add(point);
    }
    public void appendPoint(Point point){
        points.add(point);
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder=new StringBuilder("{");
        for (Point apoint:points){
            stringBuilder.append(apoint.toString());
        }
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
    public double getLength(){
        double length=0;
        for(int i=0;i<points.size()-1;i++){
            Point p1=points.get(i);
            Point p2=points.get(i+1);
            double distance=p1.distance(p2);
            length+=distance;
        }
        return length;

    }
}

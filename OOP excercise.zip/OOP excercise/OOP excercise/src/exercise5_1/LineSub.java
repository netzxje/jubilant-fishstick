package exercise5_1;

public class LineSub extends Point{
    private Point end;

    public LineSub(int x, int y,int endX,int endY) {
        super(x, y);
        this.end = new Point(endX,endY);
    }

    public LineSub(Point begin,Point end) {
        super(begin.getX(),begin.getY());
        this.end = end;
    }

    public Point getBegin(){
        return new Point(getX(),getY());
    }
    public void setBegin(Point another){
        this.setX(another.getX());
        this.setY(another.getY());
    }



    public Point getEnd() {
        return end;
    }

    public void setEnd(Point end) {
        this.end = end;
    }

    public int getBeginX(){
        return getX();
    }
    public int getBeginY(){
        return getY();
    }

    public int getEndX(){
        return end.getX();
    }

    public int getEndY(){
        return end.getY();
    }

    public void setBeginX(int x){
        setX(x);
    }

    public void setBeginY(int y){
        setY(y);
    }

    public void setBeginXY(int x,int y){
        setX(x);
        setY(y);
    }

    public void setEndX(int x){
        end.setX(x);
    }

    public void setEndY(int y){
        end.setY(y);
    }

    public void setEndXY(int x,int y){
        end.setX(x);
        end.setY(y);
    }

    public int getLength(){
        return (int) Math.sqrt(Math.pow(this.getX()-end.getX(),2)+Math.pow(this.getY()-end.getY(),2));
    }
    public double getGradient(){
        return (end.getY()-this.getY())/(end.getX()-this.getX());

    }
}

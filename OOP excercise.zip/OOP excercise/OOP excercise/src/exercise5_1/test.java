package exercise5_1;

public class test {
    public static void main(String[] args) {
        LineSub line1 = new LineSub(1, 2, 5, 6);
        System.out.println("Line1:");
        System.out.println("Begin point: " + line1.getBegin());
        System.out.println("End point: " + line1.getEnd());
        System.out.println("Length: " + line1.getLength());
        System.out.println("Gradient: " + line1.getGradient());

        Point begin = new Point(3, 4);
        Point end = new Point(7, 8);

        LineSub line2 = new LineSub(begin, end);
        System.out.println("Line2:");
        System.out.println("Begin point: " + line2.getBegin());
        System.out.println("End point: " + line2.getEnd());
        System.out.println("Length: " + line2.getLength());
        System.out.println("Gradient: " + line2.getGradient());

        line2.setBegin(new Point(10, 10));
        line2.setEnd(new Point(20, 20));
        System.out.println("After modifying Line2:");
        System.out.println("Begin point: " + line2.getBegin());
        System.out.println("End point: " + line2.getEnd());
        System.out.println("Length: " + line2.getLength());
        System.out.println("Gradient: " + line2.getGradient());
    }
}

package exercise1_2;

public class test {
    public static void main(String[] args) {
        circle cc1 = new circle(1.0);
        circle cc2 = new circle(2.0);
        circle cc3 = new circle(3.0);

        System.out.println(cc1);
        System.out.println(cc2);
        System.out.println(cc3);

        cc1.setRadius(5.0);

        System.out.println("radius is " + cc1.getRadius());
        System.out.println("Area is "+cc1.getArea());
        System.out.println("circumference is "+cc1.getCircumference());
    }
}
package exercise1_7;


public class test {
    public static void main(String[] args) {
        Date Date = new Date(12, 05, 2005);
        System.out.println(Date);





    }
}

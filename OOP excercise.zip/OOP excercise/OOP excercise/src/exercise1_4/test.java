package exercise1_4;

public class test {
    public static void main(String[] args) {
        employee employee=new employee(13,"phan huu","khoi nguyen",13000);
        System.out.println(employee);
        System.out.println("id is: "+employee.getId());
        System.out.println("firstname is: "+employee.getFirstname());
        System.out.println("lastname is : "+employee.getLastname());
        System.out.println("name is : "+employee.getname());
        System.out.println("salary is : "+employee.getSalary());
        System.out.println("annual salary: "+employee.getAnnualSalary());
        System.out.println("raisesalary after 2 year : "+employee.raiseSalary(10));
    }
}

package exercise5_2;

public class Cylinder {
    private Circle base;
    private double height;

    public Cylinder(Circle base, double hight) {
        this.base = base;
        this.height = hight;
    }

    public Circle getBase() {
        return base;
    }

    public void setBase(Circle base) {
        this.base = base;
    }

    public double getHight() {
        return height;
    }

    public void setHight(double hight) {
        this.height = hight;
    }

    public double getVolume(){
        return base.Area()*height;
    }
}

package exercise1_8;

public class test {
    public static void main(String[] args) {
        Time time=new Time(5,15,45);
        System.out.println(time);

        time.setHour(4);
        time.setMinute(5);
        time.setSecond(6);
        System.out.println(time);
        System.out.println("hour:"+time.getHour());
        System.out.println("minute:"+time.getMinute());
        System.out.println("second:"+time.getSecond());

        time.setTime(23,59,58);
        System.out.println(time);
        System.out.println(time.nextSecond());
        System.out.println(time.nextSecond().nextSecond());
        System.out.println(time.previousSecond());
        System.out.println(time.previousSecond().previousSecond());



    }
}

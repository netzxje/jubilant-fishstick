package exercise3_4;

public class test {
    public static void main(String[] args) {
        MyTime time = new MyTime(23, 59, 58);
        System.out.println("Initial Time: " + time);

        MyTime nextSecond = time.nextSecond();
        System.out.println("Next Second: " + nextSecond);

        MyTime nextMinute = time.nextMinute();
        System.out.println("Next Minute: " + nextMinute);

        MyTime nextHour = time.nextHour();
        System.out.println("Next Hour: " + nextHour);

        MyTime previousSecond = time.previousSecond();
        System.out.println("Previous Second: " + previousSecond);

        MyTime previousMinute = time.previousMinute();
        System.out.println("Previous Minute: " + previousMinute);

        MyTime previousHour = time.previousHour();
        System.out.println("Previous Hour: " + previousHour);

        time.setTime(12, 30, 45);
        System.out.println("After setTime (12:30:45): " + time);

        time.setTime(25, 61, -1); // Invalid values
        System.out.println("After setTime (Invalid): " + time);

        time.setHour(10);
        System.out.println("After setHour(10): " + time);

        time.setMinute(20);
        System.out.println("After setMinute(20): " + time);

        time.setSecond(15);
        System.out.println("After setSecond(15): " + time);

        System.out.println("Final Time (toString): " + time);
    }
}

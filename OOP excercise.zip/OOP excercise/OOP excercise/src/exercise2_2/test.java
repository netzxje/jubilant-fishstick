package exercise2_2;

public class test {
    public static void main(String[] args) {
        Author[] authors=new Author[2];
        authors[0]=new Author("khoi nguyen","nguyen@gmail.com",'n');
        authors[1]=new Author("phuc nguyen","ng@gmai.com",'g');
        Book book=new Book("OOp",authors,30000,3);
        System.out.println(book);
    }
}

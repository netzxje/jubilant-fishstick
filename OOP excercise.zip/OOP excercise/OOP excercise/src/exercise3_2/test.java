package exercise3_2;


public class test {
    public static void main(String[] args) {
        MyPolynomial myPolynomial=new MyPolynomial(6,7,2,6,7);
        MyPolynomial myPolynomial1=new MyPolynomial(5,4,2,7);
        System.out.println(myPolynomial);
        System.out.println(myPolynomial.evaluate(2));
        MyPolynomial myPolynomial2=myPolynomial.add(myPolynomial1);
        System.out.println(myPolynomial2);
        MyPolynomial myPolynomial3=myPolynomial.multiply(myPolynomial1);
        System.out.println(myPolynomial3);

    }
}

package exercise3_2;

import java.util.Arrays;

public class MyPolynomial {
    private double[] coeffs;

    public MyPolynomial(double... coeffs) {
        this.coeffs = coeffs;
    }

    public int getDegree(){
        return this.coeffs.length-1;
    }

    @Override
    public String toString() {
       StringBuilder sb=new StringBuilder();
       int degree=getDegree();
       for(int i=0;i<=degree;i++){
           if(coeffs[i]!=0){
               if(sb.length()>0){
                   sb.append("+");
               }
               if(i==0){
                   sb.append(coeffs[i]);
               }else if(i==1){
                   sb.append(coeffs[i]).append("x");
               }else sb.append(coeffs[i]).append("x^").append(i);
           }
       }
       return sb.toString();
    }

    public double evaluate(double x){
        int degree=getDegree();
        int result=0;
        for(int i=0;i<=degree;i++){
            result+=coeffs[i]*Math.pow(x,i);
        }
        return result;
    }

    public MyPolynomial add(MyPolynomial right){
        int maxDegree=Math.max(this.getDegree(),right.getDegree());
        double[] result=new double[maxDegree+1];
        for(int i=0;i<=maxDegree;i++){
            double coeff1=(this.getDegree()>=i ? this.coeffs[i] : 0);
            double coeff2=(right.getDegree()>=i ? right.coeffs[i]: 0);
            result[i]=coeff1+coeff2;
        }
        return new MyPolynomial(result);
    }
    public MyPolynomial multiply(MyPolynomial right) {
        int newDegree = this.getDegree() + right.getDegree();
        double[] resultCoeffs = new double[newDegree + 1];

        for (int i = 0; i <= this.getDegree(); i++) {
            for (int j = 0; j <= right.getDegree(); j++) {
                resultCoeffs[i + j] += this.coeffs[i] * right.coeffs[j];
            }
        }
        return new MyPolynomial(resultCoeffs);
    }



}

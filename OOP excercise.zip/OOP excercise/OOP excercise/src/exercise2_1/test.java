package exercise2_1;

public class test {
    public static void main(String[] args) {
     Author author=new Author("nguyen","nguyen@gmail.com",'n');
     Book book=new Book("C++",author,1000,5);
        System.out.println(book);
        book.setPrice(500);
        book.setQty(10);
        System.out.println("name :"+book.getNamebook());
        System.out.println("price:"+book.getPrice());
        System.out.println("qty:"+book.getQty());
        System.out.println("AUthor :"+book.getAuthor());
        System.out.println("author name:"+book.getAuthor().getName());
        System.out.println("author email:"+book.getAuthor().getEmail());






    }
}

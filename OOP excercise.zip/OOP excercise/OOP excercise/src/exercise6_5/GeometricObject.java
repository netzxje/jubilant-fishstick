package exercise6_5;

public interface GeometricObject {
    public double getPerimeter();
    public double getArea();
}

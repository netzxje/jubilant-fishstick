package exercise2_7;

public class test {
    public static void main(String[] args) {
        MyPoint begin=new MyPoint(1,1);
        MyPoint end=new MyPoint(2,2);
        MyLine myLine=new MyLine(begin,end);
        System.out.println(myLine);
        System.out.println(myLine.getLength());
        System.out.println(myLine.getGradient());
    }
}

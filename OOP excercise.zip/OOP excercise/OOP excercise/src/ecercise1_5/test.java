package ecercise1_5;

public class test {
    public static void main(String[] args) {
        InvoiceItem invoiceItem=new InvoiceItem("VKU","OOP",13,2000);
        System.out.println(invoiceItem);
        invoiceItem.setQty(15);
        System.out.println(invoiceItem);
        System.out.println("id : "+invoiceItem.getId());
        System.out.println("desc : "+invoiceItem.getDesc());
        System.out.println("qty : "+invoiceItem.getQty());
        System.out.println("Unitprice:"+invoiceItem.getUnitprice());
        System.out.println("total:"+invoiceItem.getTotal());


    }
}

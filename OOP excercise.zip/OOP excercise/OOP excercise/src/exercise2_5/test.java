package exercise2_5;

public class test {
    public static void main(String[] args) {
        Customer customer=new Customer(1,"Nguyen",'m');
        System.out.println(customer);
        Account account=new Account(2,customer,100);
        System.out.println(account);
        System.out.println(account.getCustomerName());
        System.out.println(account.deposit(50).deposit(100).deposit(50));
        System.out.println(account.withdraw(400));
    }
}

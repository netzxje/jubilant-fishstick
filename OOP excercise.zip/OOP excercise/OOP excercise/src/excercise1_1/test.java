package excercise1_1;

public class test {
    public static void main(String[] args) {
    circle cc=new circle(1.0,"red");
        System.out.println(cc);
        System.out.println("Area is: "+cc.getArea());


    }
}

package exercise1_6;

public class test {
    public static void main(String[] args) {
        Account A1=new Account("A1","khoi nguyen",88);
        Account A2=new Account("A2","phuc nguyen",0);
        System.out.println(A1);
        System.out.println(A2);
        System.out.println("id:"+A1.getId());
        System.out.println("name:"+A1.getName());
        System.out.println("balance:"+A1.getBalance());
       A1.creadit(100);
        System.out.println(A1);
        A1.debit(50);
        System.out.println(A1);
      A1.transferTo(A2,100);
        System.out.println(A1);
        System.out.println(A2);




    }
}

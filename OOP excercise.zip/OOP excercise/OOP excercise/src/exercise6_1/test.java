package exercise6_1;

import exercise4_5.Circle;
import exercise4_5.Rectangle;
import exercise4_5.Shape;
import exercise4_5.Square;

public class test {
    public static void main(String[] args) {
        exercise4_5.Shape shape1 = new exercise4_5.Shape();
        exercise4_5.Shape shape2 = new Shape("blue", false);
        System.out.println("Shape 1: " + shape1);
        System.out.println("Shape 2: " + shape2);

        exercise4_5.Circle circle1 = new exercise4_5.Circle();
        exercise4_5.Circle circle2 = new exercise4_5.Circle(2.5);
        exercise4_5.Circle circle3 = new Circle("yellow", true, 3.5);
        System.out.println("Circle 1: " + circle1);
        System.out.println("Circle 2: " + circle2);
        System.out.println("Circle 3: " + circle3);
        System.out.println("Circle 3 Area: " + circle3.getArea());
        System.out.println("Circle 3 Perimeter: " + circle3.getPerimeter());

        exercise4_5.Rectangle rect1 = new exercise4_5.Rectangle();
        exercise4_5.Rectangle rect2 = new exercise4_5.Rectangle(2.0, 4.0);
        exercise4_5.Rectangle rect3 = new Rectangle("green", false, 3.0, 6.0);
        System.out.println("Rectangle 1: " + rect1);
        System.out.println("Rectangle 2: " + rect2);
        System.out.println("Rectangle 3: " + rect3);
        System.out.println("Rectangle 3 Area: " + rect3.getArea());
        System.out.println("Rectangle 3 Perimeter: " + rect3.getPerimeter());

        Square square1 = new Square();
        Square square2 = new Square(4.0);
        Square square3 = new Square("purple", true, 5.0);
        System.out.println("Square 1: " + square1);
        System.out.println("Square 2: " + square2);
        System.out.println("Square 3: " + square3);
        System.out.println("Square 3 Area: " + square3.getArea());
        System.out.println("Square 3 Perimeter: " + square3.getPerimeter());
    }
}

package exercise6_1;

import exercise4_5.Rectangle;

public class square extends Rectangle {
    public square(String color, boolean filled, double side) {
        super(color, filled, side, side);
    }

    public square(double side) {
        super(side, side);
    }

    public square() {
        super();
    }

    public double getSide(){
        return this.getWidth();
    }

    public void setSide(double side){
        this.setLength(side);
    }

    @Override
    public void setWidth(double side) {
        super.setWidth(side);
    }

    @Override
    public void setLength(double side) {
        super.setLength(side);
    }

    @Override
    public String toString() {
        return "Square[ " + super.toString()+"]";
    }
}
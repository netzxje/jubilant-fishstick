package exercise1_3;

public class test {
    public static void main(String[] args) {
        Rectangle R1=new Rectangle(1.0f,2.0f);
        Rectangle R2=new Rectangle(2.0f,3.0f);
        Rectangle R3=new Rectangle(3.0f,4.0f);
        System.out.println(R1);
        System.out.println(R2);
        System.out.println(R3);
        R1.setLenght(6.0f);
        R1.setWidth(7.0f);
        System.out.println("length is "+R1.getLenght());
        System.out.println("width is "+R1.getWidth());
        System.out.println("area is "+R1.getArea());
        System.out.println("perimeter is "+R1.getPerimeter());

    }
}

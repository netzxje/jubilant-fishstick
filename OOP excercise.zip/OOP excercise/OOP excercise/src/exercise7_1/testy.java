package exercise7_1;

import java.util.Date;

public class testy {
    public static void main(String[] args) {
        Customer customer=new Customer("nguyen");
        customer.setMember(true);
        customer.setMemberType("Premium");

        Visit daNang=new Visit(customer,new Date());

        daNang.setProductExpense(500);
        daNang.setServiceExpense(400);
        System.out.println(daNang.getProductExpense());
        System.out.println(daNang.getServiceExpense());
        System.out.println(daNang.getTotalExpense());


    }
}

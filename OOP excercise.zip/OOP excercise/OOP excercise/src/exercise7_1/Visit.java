package exercise7_1;

import java.util.Date;

public class Visit {
    private Customer customer;
    private Date date;
    private double serviceExpense;
    private double productExpense;

    public Visit(Customer customer,Date date) {
        this.customer =customer;
        this.date = date;
        this.serviceExpense = 0;
        this.productExpense = 0;
    }


    public double getServiceExpense() {
        return serviceExpense;
    }

    public void setServiceExpense(double serviceExpense) {
        this.serviceExpense = serviceExpense;
    }

    public double getProductExpense() {
        return productExpense;
    }

    public void setProductExpense(double productExpense) {
        this.productExpense = productExpense;
    }
    public double getTotalExpense(){
        double serviceDiscount=DiscountRate.getServiceDiscountRate(customer.getMemberType());
        double productDiscount=DiscountRate.getProductDiscountRate(customer.getMemberType());
        return  (serviceExpense-serviceExpense*serviceDiscount)+(productExpense-productExpense*productDiscount);
    }

}

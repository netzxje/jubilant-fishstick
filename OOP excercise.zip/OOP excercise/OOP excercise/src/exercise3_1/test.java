package exercise3_1;

public class test {
    public static void main(String[] args) {
        MyComplex c1 = new MyComplex(3, 4);
        MyComplex c2 = new MyComplex(1, -2);
        MyComplex c3 = new MyComplex(3, 4);
        MyComplex c4 = new MyComplex();

        System.out.println("c1 real: " + c1.getReal());
        System.out.println("c1 imag: " + c1.getImag());

        c1.setReal(5);
        c1.setImag(6);
        System.out.println("c1 sau khi set: " + c1.toString());

        c1.setValue(3, 4);
        System.out.println("c1 sau khi setValue: " + c1.toString());

        System.out.println("c1 == c3? " + c1.equals(c3));
        System.out.println("c1 == c2? " + c1.equals(c2));

        System.out.println("c1 có phải số thực? " + c1.isReal());
        System.out.println("c1 có phải số ảo? " + c1.isImaginary());
        System.out.println("c4 có phải số thực? " + c4.isReal());
        System.out.println("c4 có phải số ảo? " + c4.isImaginary());

        System.out.println("Độ lớn của c1: " + c1.magnitude());
        System.out.println("Argument của c1: " + c1.argument());

        System.out.println("c1 + c2 = " + c1.addNew(c2));
        System.out.println("c1 - c2 = " + c1.subtractNew(c2));
        System.out.println("c1 * c2 = " + c1.multiply(c2));
        System.out.println("c1 / c2 = " + c1.divide(c2));

        System.out.println("Liên hợp của c1: " + c1.conjugate());
    }
}

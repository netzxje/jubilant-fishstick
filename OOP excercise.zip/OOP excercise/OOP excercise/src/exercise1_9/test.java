package exercise1_9;

public class test {
    public static void main(String[] args) {
        Ball ball=new Ball(1.1f,2.2f,10,3.3f,4.4f);
        System.out.println(ball);
        ball.setX(80.0f);
        ball.setY(35.0f);
        ball.setRadius(5);
        ball.setxDelta(4.0f);
        ball.setyDelta(6.0f);
        System.out.println(ball);
        float xMin=0.0f,xMax=100.0f,yMin=0.0f,yMax=50.0f;
        for (int i=0;i<15;i++){
            ball.move();
            System.out.println(ball);
            if ((ball.getX()+ ball.getRadius())>xMax || (ball.getX()-ball.getRadius())<xMin){
                ball.reflectHorizontal();
            }else if ((ball.getY()+ball.getRadius())>yMax || (ball.getY()-ball.getRadius())<yMin){
                ball.reflectVertical();
            }
        }
    }
}

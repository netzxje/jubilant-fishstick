package exercise3_5;

import exercise3_4.MyTime;

public class MyDate {
    private int year;
    private int month;
    private int day;
    public static String[] MONTHS={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    public static String[] DAYS={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
    public static int[] DAYS_IN_MONTHS={31,28,31,39,31,39,31,31,39,31,30,31};

    public MyDate(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }

    public static boolean isLeapYear(int year){
        return (year % 4==0 && year %100 !=0) || (year%400 ==0);
    }
    public static boolean isValiDate(int year,int month,int day){
        int maxday=DAYS_IN_MONTHS[month-1];
        if(month==2 && isLeapYear(year)){
            maxday=29;
        }
        if(day>=1 && day<=maxday){
            return true;
        }else return false;
    }

    public static int getDayOfWeek(int year, int month, int day) {
        int[] centuryTable = {6,4,2,0};
        int[] monthTable = {0, 3, 3, 6, 1, 4, 6, 2, 5, 0, 3, 5};
        int century = year / 100;
        int yearInCentury = year % 100;

        int total = day + monthTable[month - 1] + yearInCentury + yearInCentury / 4 + centuryTable[century % 4];
        if (isLeapYear(year) && (month == 1 || month == 2)) {
            total--;
        }
        return total % 7;
    }


    public void setDate(int year,int month,int day){
        this.year=year;
        this.month=month;
        this.day=day;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }
// 2024/12/05
    @Override
    public String toString() {
        int dayofweek=getDayOfWeek(this.year,this.month,this.day);
        return "MyDate{"+DAYS[dayofweek]+" "+this.day+" "+MONTHS[month-1]+" "+this.year;
    }

    public MyDate nextday(){
        int newDay=this.day+1;
        int newMonth=this.month;
        int newYear=this.year;
        int maxDay=DAYS_IN_MONTHS[newMonth-1];
        if (newMonth == 2 && isLeapYear(newYear)) {
            maxDay = 29;
        }
        if(newDay >maxDay){
            newDay=1;
            newMonth++;
            if(newMonth>12){
                newMonth=1;
                newYear++;
            }
        }
        return new MyDate(newYear,newMonth,newDay);
    }

    public MyDate nextMonth(){
        int newMonth=this.month+1;
        int newYear=this.year;
        if(newMonth>12){
            newMonth=1;
            newYear++;
        }
        return new MyDate(newYear,newMonth,this.day);
    }
    public MyDate nextYear(){
        return new MyDate(this.year+1,this.month,this.day);
    }
    public MyDate previousDay(){
        int newDay=this.day-1;
        int newMonth=this.month;
        int newYear=this.year;
        if(newDay<=0){
            newMonth--;
            int maxday=DAYS_IN_MONTHS[newMonth-1];
            if (newMonth == 2 && isLeapYear(newYear)) {
                maxday = 29;
            }
            newDay=maxday;
            if(newMonth<=0){
                newMonth=12;
                newYear--;
            }
        }
        return new MyDate(newYear,newMonth,newDay);
    }
    public MyDate previousMonth(){
        int newMonth=this.month-1;
        int newYear=this.year;
        if(newMonth<=0){
            newMonth=12;
            newYear--;
        }
        return new MyDate(newYear,newMonth,this.day);
    }
    public MyDate previousYear(){
        return new MyDate(this.year-1,this.month,this.day);
    }
}

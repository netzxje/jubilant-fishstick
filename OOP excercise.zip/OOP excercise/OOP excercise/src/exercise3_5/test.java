package exercise3_5;

public class test {
    public static void main(String[] args) {
        MyDate date = new MyDate(2024, 12, 5);
        System.out.println("Initial date: " + date);

        System.out.println("2024 is leap year: " + MyDate.isLeapYear(2024));
        System.out.println("2023 is leap year: " + MyDate.isLeapYear(2023));

        System.out.println("Valid date (2024-02-29): " + MyDate.isValiDate(2024, 2, 29));
        System.out.println("Valid date (2023-02-29): " + MyDate.isValiDate(2023, 2, 29));
        System.out.println("Valid date (2024-11-31): " + MyDate.isValiDate(2024, 11, 31));

        System.out.println("Day of the week for 2025-2-15: " + MyDate.DAYS[MyDate.getDayOfWeek(2025, 2, 15)]);
        System.out.println("Day of the week for 2000-01-01: " + MyDate.DAYS[MyDate.getDayOfWeek(2000, 1, 1)]);

        date.setDate(2023, 11, 15);
        System.out.println("Date after setDate: " + date);

        MyDate nextDay = date.nextday();
        System.out.println("Next day: " + nextDay);

        MyDate nextMonth = date.nextMonth();
        System.out.println("Next month: " + nextMonth);

        MyDate nextYear = date.nextYear();
        System.out.println("Next year: " + nextYear);

        MyDate previousDay = date.previousDay();
        System.out.println("Previous day: " + previousDay);

        MyDate previousMonth = date.previousMonth();
        System.out.println("Previous month: " + previousMonth);

        MyDate previousYear = date.previousYear();
        System.out.println("Previous year: " + previousYear);

        MyDate leapDay = new MyDate(2024, 2, 28);
        System.out.println("Next day (2024-02-28): " + leapDay.nextday());


        MyDate marchFirst = new MyDate(2024, 3, 1);
        System.out.println("Previous day (2024-03-01): " + marchFirst.previousDay());

        MyDate december = new MyDate(2024, 12, 15);
        System.out.println("Next month (2024-12-15): " + december.nextMonth());

        MyDate january = new MyDate(2024, 1, 15);
        System.out.println("Previous month (2024-01-15): " + january.previousMonth());
    }
}
